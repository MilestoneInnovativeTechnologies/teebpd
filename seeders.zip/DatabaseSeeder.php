<?php

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        $this->call([
            Milestone\Appframe\Seeder\DatabaseSeeder::class,
            Milestone\Teebpd\Seeder\DatabaseSeeder::class,
            ResourceFormUploadTableSeeder::class,
//            ItemGroupMasterTableSeeder::class,
//            ProductTableSeeder::class,
//            ProductImageTableSeeder::class,
//            TeebUserAddSeeder::class
        ]);
        // $this->call(UsersTableSeeder::class);
    }
}
