<?php

use Illuminate\Database\Seeder;

class TeebUserAddSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $_ = \DB::statement('SELECT @@GLOBAL.foreign_key_checks');
        \DB::statement('set foreign_key_checks = 0');
        \DB::statement("INSERT INTO `users` (`name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES ('TEEB Admin', 'admin@teeb.com', NOW(), '$2y$10$5U6ht8rM3wFBnEwQIWTTW.68XPhlWytoorxqjU3cTVYOHvERpiWeG', NULL, NOW(), NOW());");
        \DB::statement("INSERT INTO `__groups` (`name`, `description`, `title`, `created_at`, `updated_at`) VALUES ('teeb_administrators', 'Administrators of TEEB', 'Administrator', NOW(), NOW());");
        \DB::statement("INSERT INTO `__roles` (`name`, `description`, `title`, `created_at`, `updated_at`) VALUES ('teeb_administrator', 'Administrators of TEEB', 'TEEB Administrator', NOW(), NOW());");
        \DB::statement("INSERT INTO `__group_roles` (`group`, `role`, `created_at`, `updated_at`) VALUES (4, 4, NOW(), NOW());");
        \DB::statement("INSERT INTO `__group_users` (`group`, `user`, `created_at`, `updated_at`) VALUES (4, 1, NOW(), NOW());");
        \DB::statement("INSERT INTO `__resource_roles` (`resource`, `role`, `actions_availability`, `actions`, `created_at`, `updated_at`) VALUES (301, 4, 'All', NULL, NOW(), NOW());");
        \DB::statement("INSERT INTO `__resource_roles` (`resource`, `role`, `actions_availability`, `actions`, `created_at`, `updated_at`) VALUES (302, 4, 'All', NULL, NOW(), NOW());");
        \DB::statement("INSERT INTO `__resource_roles` (`resource`, `role`, `actions_availability`, `actions`, `created_at`, `updated_at`) VALUES (303, 4, 'All', NULL, NOW(), NOW());");
        \DB::statement("INSERT INTO `__resource_roles` (`resource`, `role`, `actions_availability`, `actions`, `created_at`, `updated_at`) VALUES (304, 4, 'All', NULL, NOW(), NOW());");
        \DB::statement("INSERT INTO `__resource_roles` (`resource`, `role`, `actions_availability`, `actions`, `created_at`, `updated_at`) VALUES (305, 4, 'All', NULL, NOW(), NOW());");
        \DB::statement("INSERT INTO `__resource_roles` (`resource`, `role`, `actions_availability`, `actions`, `created_at`, `updated_at`) VALUES (306, 4, 'All', NULL, NOW(), NOW());");
        \DB::statement("INSERT INTO `__resource_roles` (`resource`, `role`, `actions_availability`, `actions`, `created_at`, `updated_at`) VALUES (307, 4, 'All', NULL, NOW(), NOW());");
        \DB::statement("INSERT INTO `__resource_roles` (`resource`, `role`, `actions_availability`, `actions`, `created_at`, `updated_at`) VALUES (308, 4, 'All', NULL, NOW(), NOW());");
        \DB::statement("INSERT INTO `__resource_roles` (`resource`, `role`, `actions_availability`, `actions`, `created_at`, `updated_at`) VALUES (309, 4, 'All', NULL, NOW(), NOW());");
        \DB::statement("INSERT INTO `__resource_roles` (`resource`, `role`, `actions_availability`, `actions`, `created_at`, `updated_at`) VALUES (310, 4, 'All', NULL, NOW(), NOW());");
        \DB::statement('set foreign_key_checks = ' . $_);
    }
}
