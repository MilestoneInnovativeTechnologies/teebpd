<?php

use Illuminate\Database\Seeder;

class ProductImageTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $_ = \DB::statement('SELECT @@GLOBAL.foreign_key_checks');
        \DB::statement('set foreign_key_checks = 0');
        \Milestone\Teebpd\Model\ProductImage::truncate()
        ;
        \DB::statement("
        
INSERT INTO `product_images` (`name`,`product`,`image`,`default`,`created_at`,`updated_at`) VALUES 
('AFTER SHAVE - 1','1','1','Yes',NOW(),NOW()),
('AFTER SHAVE - 2','1','2','No',NOW(),NOW()),
('AFTER SHAVE - 1','2','3','Yes',NOW(),NOW()),
('AFTER SHAVE - 2','2','4','No',NOW(),NOW()),
('AFTER SHAVE - 1','3','5','Yes',NOW(),NOW()),
('AFTER SHAVE - 2','3','6','No',NOW(),NOW()),
('BAG - 1','4','7','Yes',NOW(),NOW()),
('BAG - 2','4','8','No',NOW(),NOW()),
('WHITE  - 1','5','9','Yes',NOW(),NOW()),
('WHITE  - 2','5','10','No',NOW(),NOW()),
('- - 1','6','11','Yes',NOW(),NOW()),
('- - 2','6','12','No',NOW(),NOW()),
('BODY SPALSH - 1','7','13','Yes',NOW(),NOW()),
('BODY SPALSH - 2','7','14','No',NOW(),NOW()),
('BODY SPLASH - 1','8','15','Yes',NOW(),NOW()),
('BODY SPLASH - 2','8','16','No',NOW(),NOW()),
('BODY SPLASH - 1','9','17','Yes',NOW(),NOW()),
('BODY SPLASH - 2','9','18','No',NOW(),NOW()),
('BODY SPRAY - 1','10','19','Yes',NOW(),NOW()),
('BODY SPRAY - 2','10','20','No',NOW(),NOW()),
('BAKHOOR BKTM 1002 - 1','11','21','Yes',NOW(),NOW()),
('BAKHOOR BKTM 1002 - 2','11','22','No',NOW(),NOW()),
('BUKHOOR HAMDAN200 GM - 1','12','23','Yes',NOW(),NOW()),
('BUKHOOR HAMDAN200 GM - 2','12','24','No',NOW(),NOW()),
('BUKHOOR - 1','13','25','Yes',NOW(),NOW()),
('BUKHOOR - 2','13','26','No',NOW(),NOW()),
('NO27 CON38/33386-929107G - 1','14','27','Yes',NOW(),NOW()),
('NO27 CON38/33386-929107G - 2','14','28','No',NOW(),NOW()),
('NO52 CON38/33406-929127G - 1','15','29','Yes',NOW(),NOW()),
('NO52 CON38/33406-929127G - 2','15','30','No',NOW(),NOW()),
('CHILD - 1','16','31','Yes',NOW(),NOW()),
('CHILD - 2','16','32','No',NOW(),NOW()),
('EAU DE COLOGN - 1','17','33','Yes',NOW(),NOW()),
('EAU DE COLOGN - 2','17','34','No',NOW(),NOW()),
('EDP - 1','18','35','Yes',NOW(),NOW()),
('EDP - 2','18','36','No',NOW(),NOW()),
('- - 1','19','37','Yes',NOW(),NOW()),
('- - 2','19','38','No',NOW(),NOW()),
('- - 1','20','39','Yes',NOW(),NOW()),
('- - 2','20','40','No',NOW(),NOW()),
('EDT - 1','21','41','Yes',NOW(),NOW()),
('EDT - 2','21','42','No',NOW(),NOW()),
('- - 1','22','43','Yes',NOW(),NOW()),
('- - 2','22','44','No',NOW(),NOW()),
('- - 1','23','45','Yes',NOW(),NOW()),
('- - 2','23','46','No',NOW(),NOW()),
('SO FRECH - 1','24','47','Yes',NOW(),NOW())
        
        ");
        \DB::statement('set foreign_key_checks = ' . $_);
    }
}
